public class StudentManagement {
    Student[] students = new Student[101];
    int num = 0;

    public static boolean sameGroup(Student s1, Student s2) {
        return s1.getGroup().equals(s2.getGroup());
    }

    public void addStudent(Student newStudent) {
        if (newStudent != null && num < 100) {
            students[num] = newStudent;
            num++;
        }
    }

    // return list of student by class
    public String studentsByGroup() {
        String allclass = "";
        String liststudent = "";
        for (int i = 0; i < num; i++) {
            String group = students[i].getGroup();
            if (allclass.contains(group) == true) {
                continue;
            }
            allclass += group + " ";
            liststudent += group + "\n";
            liststudent += students[i].getInfo() + "\n";
            for (int j = i + 1; j < num; j++) {
                if (sameGroup(students[i], students[j]) == true) {
                    liststudent += students[j].getInfo() + "\n";
                }
            }
        }
        return liststudent.trim();
    }

    //Remove a student whose id same input id
    public void removeStudent(String id) {
        for (int i = 0; i < num - 1; i++) {
            if ((students[i].getId()).equals(id) == true) {
                for (int j = i + 1; j < num; j++) {
                    students[j - 1] = students[j];
                }
                num--;
                break;
            }
        }
        if (students[num - 1] != null && (students[num - 1].getId()).equals(id) == true) {
            students[num - 1] = null;
            num--;
        }
    }
}
